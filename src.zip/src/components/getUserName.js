import React from "react";

function GetUserName() {
  return <div></div>;
}

export default GetUserName;
