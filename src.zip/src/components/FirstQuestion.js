import React from "react";

function FirstQuestion() {
  return <div></div>;
}

export default FirstQuestion;
