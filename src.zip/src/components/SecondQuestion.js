import React from "react";

function SecondQuestion() {
  return <div></div>;
}

export default SecondQuestion;
