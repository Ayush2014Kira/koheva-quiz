import React from "react";

function FourthQuestion() {
  return <div></div>;
}

export default FourthQuestion;
