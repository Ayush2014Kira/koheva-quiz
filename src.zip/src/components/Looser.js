import React from "react";

function Looser() {
  return <div></div>;
}

export default Looser;
