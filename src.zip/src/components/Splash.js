import React from "react";

export default function Splash() {
  return <div></div>;
}
