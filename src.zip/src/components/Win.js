import React from "react";

function Win() {
  return <div></div>;
}

export default Win;
