import React from "react";

function ThirdQuestion() {
  return <div></div>;
}

export default ThirdQuestion;
